# Hotel-Managment-System
This project represents an effiicient approach for a private businessmnan to deal with online booking 

#Description
We were asked to use any programming language and complete this project.This basically provided tourist to book their rooms online with remote transactions.It also provided the details of dates available,different category of rooms and their prices.The admin had the only authority to deal with the information provided by the user.
This project was completed with the help of html,css,bootstrap for frontend and Php and mysql for backend
